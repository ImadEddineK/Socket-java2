import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.StringTokenizer;

public class client {
	
	
	

	public static void main(String[] args) {
		int port = 200;
		String host = "localhost";
		InetAddress adr;
		DatagramSocket socket;
		DatagramPacket packet;
		String msg_a_envoyer = "bonjour ce message est envoy� au serveur";
		
		try {
			adr = InetAddress.getByName(host);
			socket = new DatagramSocket();
			byte[] data = (new String(msg_a_envoyer)).getBytes();
			packet = new DatagramPacket(data,data.length,adr,port);
			socket.send(packet);
			
			byte[] reponse= new byte[15];
			packet.setData(reponse);
			packet.setLength(reponse.length);
			socket.receive(packet);
			int nb_de_mots = ByteBuffer.wrap(packet.getData()).getInt();;
			System.out.println("recue du serveur "+nb_de_mots);
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
}
