import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class lign {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String line = null;
		int comp=0;
		try {
			BufferedReader lecf= new BufferedReader(new FileReader("C:\\Users\\Luxis Computers\\Desktop\\h.txt"));
			do {
				line=lecf.readLine();
				if(line==null) {break;}
				comp=comp+ (new StringTokenizer(line, " ,.;:_-+*/\"{}()=<>\t\n") ).countTokens();
				System.out.println(comp);
			}while(line!=null);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
