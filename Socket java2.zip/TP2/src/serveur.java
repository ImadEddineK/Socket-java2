import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.StringTokenizer;


public class serveur {
	static int i=0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int port = 200;
		DatagramPacket packet;
		int compteur=0;
		try {
			
			DatagramSocket socket = new DatagramSocket(port);
			
			String chaine_rec;
			byte[] data = new byte[15];
			packet = new DatagramPacket(data,data.length);
            socket.receive(packet);
            chaine_rec = new String(packet.getData());
            System.out.println("msg recue "+chaine_rec);
            compteur=compteur+ (new StringTokenizer(chaine_rec, " ,.;:_-+*/\"{}()=<>\t\n") ).countTokens();
            
			
			
			System.out.println(packet.getAddress()+":"+packet.getPort());
			
			byte[] reponse = ByteBuffer.allocate(4).putInt(compteur).array();
			packet.setData(reponse);
			packet.setLength(reponse.length);
			
			socket.send(packet);
			
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
